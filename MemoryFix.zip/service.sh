#!/system/bin/sh
# Wait for boot to finish
while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 5
done

# 1. Relax Memory Pressure (PSI)
# Pixel ROMs kill apps when "thrashing" occurs. We raise the limit to 95%.
resetprop ro.lmk.thrashing_limit 95
resetprop ro.lmk.thrashing_limit_decay 10
resetprop ro.lmk.kill_heaviets_task false

# 2. Disable Phantom Process Killer
device_config put activity_manager max_phantom_processes 2147483647
settings put global settings_enable_monitor_phantom_procs false

# 3. Restart LMKD to apply
stop lmkd
start lmkd
